<!-- <hr class="amarillo visible-xs">
<div class="store-filter clearfix">
<form name="filtros">
<div class="row">
    <div class="col-md-4">
        <select class="form-control" name="ancho" id="ancho">
            <option value="">Ancho</option>
            <option value="1">8.2</option>
            <option value="1">11</option>
            <option value="1">12</option>
            <option value="1">120</option>
            <option value="1">215</option>
            <option value="1">235</option>
            <option value="1">245</option>
            <option value="1">250</option>
            <option value="1">255</option>
            <option value="1">260</option>
        </select>
    </div>
    <div class="col-md-4">
        <select class="form-control" name="perfil" id="perfil">
            <option value="">Perfil</option>
        </select>
    </div>
    <div class="col-md-4">
        <select class="form-control" name="aro" id="aro">
            <option value="">Aro</option>
        </select>
    </div>
</div>
</form>
<br>
<hr >
</div> -->