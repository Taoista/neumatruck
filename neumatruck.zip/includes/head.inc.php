<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content="NeumaTruck.cl es una de las principales comercializadoras de marcas líderes de neumáticos para camión y buses, y líneas pesadas. Importamos solo marcas innovadoras con productos de alta tecnología en la industria">


<meta name="keywords" content=" neumaticos camion, neumaticos camion michelin, neumaticos camion pirelli, neumáticos camión dunlop, neumaticos camion linglong, neumaticos camion goodride, neumaticos camion triangle, neumaticos camion chaoyang, neumaticos camion sumitomo, neumaticos camion windforce,  neumaticos camion samson, neumaticos camion fesite, neumaticos camion chaoyang, neumaticos camion Golden Crown, neumaticos camion bridgestone, neumaticos direccion, neumaticos traccion, neumaticos camion carretera, neumaticos traccionales, neumáticos para carretera, neumaticos para faena, neumatico mixto, neumaticos de camion, neumaticos para camion, ruedas de camion, ruedas camion, neumaticos para camiones precios, Neumaticos camion baratos, ruedas de camion baratos, neumatico camion precio, venta de neumaticos para camiones, neumaticos de invierno para camion, neumaticos camion online, neumaticos de camiones nuevos, neumaticos para camiones precios, neumatico 11 r22.5, neumatico 295 80 r22.5, neumaticos 215 75 r17.5, neumaticos agricola, ruedas tractor, neumaticos de tractor, neumatico agricola precio, neumatico 12 r22.5, neumaticos macizos, neumaticos 17.5, neumaticos mineria, neumaticos para construccion, neumaticos 23.5, neumaticos cargador frontal, neumaticos motoniveladoras, neumatico para cargador, neumatico forestal, neumatico grua horquilla, neumaticos maquinaria pesada, neumatico 275 80 r22.5, neumáticos otr, neumatico pantanero, neumaticos de bus, neumaticos buses, neumático 255 70 r22.5, neumático industrial, neumático 12.00 r24, neumático 1200, 235 75 r17.5, 1200 r20, 315 80 r22.5,  750 75 r17.5">


<title><?php echo $pagina; ?></title>


<?php include('includes/css.php'); ?>
<!-- ! DEPRECATED -->
<!-- Smartsupp Live Chat script -->
<!-- <script type="text/javascript">
  var _smartsupp = _smartsupp || {};
  _smartsupp.key = '1282424d565fce81924ea423549a605314e60f03';
  window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
  })(document);



</script> -->
