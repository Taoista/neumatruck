

	<meta name = "facebook-domain-verify" content = "hmhiq76ah4inz05pdl0jgt08inex1h" />

<!-- Google font -->

	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">



	<!-- Bootstrap -->

	<link type="text/css" rel="stylesheet" href="<?php echo _GetDomain; ?>css/bootstrap.min.css" />



	<!-- Slick -->

	<link type="text/css" rel="stylesheet" href="<?php echo _GetDomain; ?>css/slick.css" />

	<link type="text/css" rel="stylesheet" href="<?php echo _GetDomain; ?>css/slick-theme.css" />



	<!-- nouislider -->

	<link type="text/css" rel="stylesheet" href="<?php echo _GetDomain; ?>css/nouislider.min.css" />



	<!-- Font Awesome Icon -->

	<link rel="stylesheet" href="css/font-awesome.min.css">



	<!-- Custom stlylesheet -->

	<link type="text/css" rel="stylesheet" href="<?php echo _GetDomain; ?>css/style.css?ver=1.4" />

	<link rel="stylesheet" type="text/css" href="<?php echo _GetDomain; ?>js/typeahead.css?ver=1.6">



	<!-- Favicon -->
 
	<link rel="icon" type="image/png" href="<?php echo _GetDomain; ?>img/2.0/favicon.png">



	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

	<!--[if lt IE 9]>

		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>

		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

		<![endif]-->



<!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-159179503-1"></script>

<script>

	window.dataLayer = window.dataLayer || [];

	function gtag(){dataLayer.push(arguments);}

	gtag('js', new Date());

	gtag('config', 'UA-159179503-1');

</script>
<!-- FACEBOOK VERIFICADOR DOMINIO PIXEL -->
<meta name="facebook-domain-verification" content="hmhiq76ah4inz05pdl0jgt08inex1h" />

<!-- Facebook Pixel Code -->



<!-- End Facebook Pixel Code -->



<!-- esto es el hotja -->

<script>

    (function(h,o,t,j,a,r){

        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};

        h._hjSettings={hjid:2147404,hjsv:6};

        a=o.getElementsByTagName('head')[0];

        r=o.createElement('script');r.async=1;

        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;

        a.appendChild(r);

    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');

</script>

<!-- End Facebook Pixel Code -->

<!-- Ivana la cabezona codigo segumiento formulario -->

<!-- Global site tag (gtag.js) - Google Ads: 720676427 -->

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-720676427">

</script>

<script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);}

	gtag('js', new Date());

	gtag('config', 'AW-720676427');

</script>

<!-- VERIFICACION FACEBOK PAGINA FACEBBOK -->

<meta name = "facebook-domain-verify" content = "hmhiq76ah4inz05pdl0jgt08inex1h" />


		<!-- /MAIN HEADER -->

		<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','GTM-W39SRJ6');</script>


<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '4295041700542357'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=4295041700542357&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
