<?php

// if($_SERVER['HTTP_HOST'] == "localhost"){
//     $link = mysql_connect("localhost", "root", "");
//     mysql_select_db("neumatruck",$link) OR DIE ("Error: No es posible establecer la conexión");
//     mysql_set_charset('utf8');
// }else{
    $link = mysql_connect("localhost", "neum45356_neumatruck", "7340458Tao");
    mysql_select_db("neum45356_neumatruck",$link) OR DIE ("Error: No es posible establecer la conexión");
    mysql_set_charset('utf8');
// }

?>
 